package com.example.projectfoodorderingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

import java.util.Objects;

public class Signup extends AppCompatActivity {

    Button btn , btn2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        Objects.requireNonNull(getSupportActionBar()).hide();
        //for hiding qaction bar

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

btn = findViewById(R.id.signupp);


               btn.setOnClickListener(view -> {
               Intent intent = new Intent(Signup.this, Cato_gories.class);
               startActivity(intent);
               });

              btn2 = findViewById(R.id.login);

              btn2.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View view) {
                      Intent intent = new Intent(Signup.this,Login.class);
                      startActivity(intent);
                  }
              });


    }
}