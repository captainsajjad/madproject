package com.example.projectfoodorderingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import java.util.Objects;

public class Cato_gories extends AppCompatActivity {
    ImageView imgse;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cato_gories);

        Objects.requireNonNull(getSupportActionBar()).hide();
        //for hiding qaction bar

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        imgse = findViewById(R.id.sandii);

        imgse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Cato_gories.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}