package com.example.projectfoodorderingapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
//import android.view.View;
//import android.view.WindowManager;
//import android.widget.Button;
//import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.projectfoodorderingapp.Adapters.MainAdapter;
import com.example.projectfoodorderingapp.Models.MainModel;
import com.example.projectfoodorderingapp.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
//    String increment, decrement;
//    TextView quantity;
//    int count;

    ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        Objects.requireNonNull(getSupportActionBar()).hide();
        //for hiding qaction bar

//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //this is for increatment or decrement

//        increment.findViewById(R.id.substract);
//        decrement.findViewById(R.id.add);
//
//       quantity.findViewById(R.id.quantity);
//
//        increment.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//               count ++;
//               quantity.setText(""+count);
//            }
//        });
//decrement.setOnClickListener(new View.OnClickListener() {
//    @Override
//    public void onClick(View v) {
//        if(count<=1) count =0;
//        else
//            count--;
//        quantity.setText(""+count);
//    }
//});

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //adding food data like image, name, price, description


        ArrayList<MainModel> list = new ArrayList<>();

        list.add(new MainModel(R.drawable.burger, "Beaf Burger","4", "Tasty Beaf Burger With Triple Layers" ));
        list.add(new MainModel(R.drawable.chesse, "Chesezy Burger","5", "Triple Layers Chese Burger" ));
        list.add(new MainModel(R.drawable.burger, "Beaf Burger","4", "Tasty Beaf Burger With Triple Layers" ));
        list.add(new MainModel(R.drawable.chesse, "Chesezy Burger","5", "Triple Layers Chese Burger" ));
        list.add(new MainModel(R.drawable.burger, "Beaf Burger","4", "Tasty Beaf Burger With Triple Layers" ));
        list.add(new MainModel(R.drawable.chesse, "Chesezy Burger","5", "Triple Layers Chese Burger" ));


    //now using adapert here

        MainAdapter adapter = new MainAdapter(list, this);
        binding.re.setAdapter(adapter);

        //Using Linear layout manager

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        binding.re.setLayoutManager(layoutManager);
    }
    //inflating menu from res file


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    //creating this function for orders page or can say list of orders which the user had ordered...

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {


        switch (item.getItemId()){
            case  R.id.orderse:
                // now creating a intent for navigate directly to order list or can say orders

                startActivity(new Intent(MainActivity.this, OrderActivity.class));
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}