package com.example.projectfoodorderingapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.os.Bundle;
import android.view.WindowManager;

import com.example.projectfoodorderingapp.Adapters.OrdersAdapter;
import com.example.projectfoodorderingapp.Models.OrdersModel;
import com.example.projectfoodorderingapp.databinding.ActivityOrderBinding;

import java.util.ArrayList;
import java.util.Objects;

public class OrderActivity extends AppCompatActivity {

    ActivityOrderBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityOrderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

//        Objects.requireNonNull(getSupportActionBar()).hide();
        //for hiding qaction bar

//        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        //This function is creating for getting rders for dbhelper

        DBHelper helper = new DBHelper(this);
        ArrayList<OrdersModel> list = helper.getOrders();


        OrdersAdapter adapter = new OrdersAdapter(list, this);
        binding.orderRecyclerView.setAdapter(adapter);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        binding.orderRecyclerView.setLayoutManager(layoutManager);
    }
}